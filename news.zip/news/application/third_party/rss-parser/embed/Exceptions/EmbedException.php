<?php

namespace Embed\Exceptions;

use Exception;

class EmbedException extends Exception
{
}
